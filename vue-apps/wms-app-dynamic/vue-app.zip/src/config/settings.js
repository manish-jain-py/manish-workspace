const settings = {

  account: {
    authorization: 'NLAuth nlauth_account=TSTDRV1796256, nlauth_email=majain@netsuite.com, nlauth_signature=manish@netsuite123A',
  }

}

export default settings
