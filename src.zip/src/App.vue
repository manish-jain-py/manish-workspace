<template>

  <div id="app">

    <reload-modal v-if="reloadFlag"></reload-modal>

    <div v-else>

      <app-header v-bind:items="appConfig.menu" v-bind:pageTitle="pageTitle"></app-header>

      <dynamic-content :currentPage="currentPage" :key="currentPageKey"></dynamic-content>

    </div>

  </div>

</template>

<script>

  import axios from 'axios'
  import AppHeader from './components/AppHeader.vue'
  import DynamicContent from './components/DynamicPage.vue'
  import ReloadModal from './components/base_components/ReloadModal.vue'
  import * as appActions from './config/ActionMap.js'
  import * as StaticConfig from './config/StaticConfig.json'
  import * as mutationTypes from './components/store/mutation-types.js'

  export default {

    name: 'App',

    data: function () {
      return {
        appConfig: {pages: {}, components: {}},
        reloadFlag: false,
        currentPageKey: 1
      }
    },

    computed: {
      pages: function () {
        return this.appConfig.pages
      },
      currentPage: function () {
        return this.$store.state.currentPage
      },
      pageTitle: function () {
        if (this.currentPage) {
          return this.pages[this.$store.state.currentPage].pageTitle
        }
      }
    },

    components: {
      AppHeader,
      DynamicContent,
      ReloadModal
    },

      methods: {
        fetchAppConfig: function () {
          if (appActions.USE_LOCAL_CONFIG) {
            this.appConfig = StaticConfig
            this.$store.commit(mutationTypes.UPDATE_APP_CONFIG, this.appConfig)
            this.$store.commit(mutationTypes.INITIALIZE_STORE)
            // check if the user was in the middle of a session
            if (!this.$store.state.currentPage || this.$store.state.currentPage === this.appConfig.defaults.landingPage) {
              this.$store.commit(mutationTypes.SET_CURRENT_PAGE, this.appConfig.defaults.landingPage)
            } else {
              this.reloadFlag = true
            }
            return
          }
          axios.get(appActions.FETCH_APP_CONFIG)
            .then(response => {
              this.appConfig = response.data
              this.$store.commit(mutationTypes.UPDATE_APP_CONFIG, this.appConfig)
              this.$store.commit(mutationTypes.INITIALIZE_STORE)

              // check if the user was in the middle of a session
              if (!this.$store.state.currentPage || this.$store.state.currentPage === this.appConfig.defaults.landingPage) {
                  this.$store.commit(mutationTypes.SET_CURRENT_PAGE, this.appConfig.defaults.landingPage)
              } else {
                  this.reloadFlag = true
              }
          })
        }
      },

    created: function () {
      this.fetchAppConfig()
    }

  }

</script>
