export const USE_LOCAL_CONFIG = false

export const FETCH_APP_CONFIG = 'https://system.netsuite.com/app/site/hosting/restlet.nl?script=148&deploy=1'

export const TEST_URL = 'https://system.netsuite.com/app/site/hosting/restlet.nl?script=148&deploy=1'

export const USER_ROLE_URL = 'https://system.netsuite.com/app/site/hosting/restlet.nl?script=142&deploy=1'
