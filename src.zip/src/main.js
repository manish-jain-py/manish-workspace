import Vue from 'vue'
import App from './App.vue'
import store from './components/store'
import 'font-awesome/css/font-awesome.min.css'
// import 'bootstrap/dist/css/bootstrap.css'
import '../common.scss'

var app = new Vue({
  el: '#app',
  render: h => h(App),
  store
})

export default app
