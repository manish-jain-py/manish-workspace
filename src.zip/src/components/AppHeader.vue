<template>

  <div class="header">

    <div class="header-content">
      {{ pageTitle }}
    </div>

    <div id="page-menu" class="menu" v-bind:class="{ 'menu-collapsed': !isMenuOpen }">

      <div class="menu-bar " @click="toggleMenu" v-bind:class="{ 'menu-open': isMenuOpen }">
        <i class="fa fa-bars"></i>
      </div>

      <div class="menu-content " v-bind:class="{ 'menu-inactive': !isMenuOpen }">
        <ul class="menu-items">
          <li class="menu-item" v-for="item in items" v-if="isMenuItemApplicable(item)" @click="sendAction(item)" :key="item.menuId">
            <i class="menu-icon " v-bind:class="item.icon"></i>
            <span>{{ item.title }}</span>
          </li>
        </ul>
        <div class="menu-blank"></div>
      </div>

    </div>

  </div>

</template>

<script>
  import axios from 'axios'
  import actionAPI from './common/MobileAction.js'
  import {USER_ROLE_URL} from '../config/ActionMap.js'

  export default {

    data: function () {
      return {
        componentType: 'AppHeader',
        isMenuOpen: false,
        userRole: ''
      }
    },

    props: ['pageTitle', 'items'],

    methods: {

      getUserRole () {
        axios.get(USER_ROLE_URL)
          .then(response => {
            this.userRole = response.data
          })
      },

      toggleMenu: function () {
        this.isMenuOpen = !this.isMenuOpen
      },

      isMenuItemApplicable: function (menuItem) {
        var rolesArr = menuItem.accessibleRoles.split(',')
        if (rolesArr.length === 1 && rolesArr[0] === '') {
          return true
        }
        for (var roleIndex in rolesArr) {
          if (rolesArr[roleIndex].toLowerCase() === this.userRole.toLowerCase()) {
            return true
          }
        }
        return false
      },

      sendAction: function (menuItem) {
        var actionObject = menuItem.action
        actionAPI.resolveAction(actionObject, this, this.$parent.pages, this.$parent.components, menuItem)
        this.isMenuOpen = false
      }

    },

    created: function () {
      this.getUserRole()
    }

  }

</script>

<style lang="scss" scoped>

  @import './base_components/styles/AppHeader.scss';

</style>
