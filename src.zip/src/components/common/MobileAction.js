import axios from 'axios'

const actionAPI = (function () {
  var PARENT_ELEMENT_COMPONENT
  var CURRENT_PAGE_COMPONENT

  var CORE_ACTIONS = {}
  var HELPER_METHODS = {}
  var MOBILE_API = {}
  var USER_SCRIPT = {}

  function resolveAction (actionObject, actionParentComponent, pages = null, components = null, menuItem = null, currentPageComponents = null) {
    PARENT_ELEMENT_COMPONENT = actionParentComponent
    CURRENT_PAGE_COMPONENT = PARENT_ELEMENT_COMPONENT.$parent
    var actionResponse = false

    switch (actionObject.actionType) {
      case 'Navigation':
        actionResponse = CORE_ACTIONS.navigateAction(actionObject)
        break
      case 'URL Navigation':
        actionResponse = CORE_ACTIONS.urlNavigateAction(actionObject, menuItem)
        break
      case 'ForwardForm':
        actionResponse = CORE_ACTIONS.forwardFormAction(actionObject, pages, components, false, currentPageComponents)
        break
      case 'BackwardForm':
        actionResponse = CORE_ACTIONS.backwardFormAction(actionObject, pages, components, currentPageComponents)
        break
      case 'SubmitForm':
        actionResponse = CORE_ACTIONS.forwardFormAction(actionObject, pages, components, true, currentPageComponents)
        break
      case 'GetOnLoadDataRestlet':
        actionResponse = CORE_ACTIONS.getOnLoadDataAction(actionObject, 'restlet', actionParentComponent)
        break
      case 'Client Function':
        actionResponse = CORE_ACTIONS.executeClientAction(actionObject)
        break
    }

    return actionResponse
  }

  CORE_ACTIONS.navigateAction = function (actionObject) {
    var targetPageId

    for (let index in actionObject.params) {
      if (actionObject.params[index].paramKey === 'page_id') {
          targetPageId = actionObject.params[index].paramValue
      }
    }

    var resolvedParams = HELPER_METHODS.resolveParams(actionObject.params)
    console.log(resolvedParams)

    var conditionObject
    if (actionObject.conditions && actionObject.conditions.length > 0) {
      for (let index in actionObject.conditions) {
        conditionObject = actionObject.conditions[index]
        console.log(conditionObject.conditionExpression)
        var resolvedConditionExpression = HELPER_METHODS.resolveConditionExpression(conditionObject.conditionExpression)
        console.log(resolvedConditionExpression)
        if (eval(resolvedConditionExpression)) {
          targetPageId = conditionObject.conditionValue
        }
      }
    }
    PARENT_ELEMENT_COMPONENT.$store.commit('SET_CURRENT_PAGE', targetPageId)
    return true
  }

  CORE_ACTIONS.urlNavigateAction = function (actionObject, menuItem) {
    var url = actionObject.url
    var isNewWindow = menuItem.openInNewWindow
    if (isNewWindow) {
      window.open(url, '_blank')
    } else {
      window.open(url, '_self')
    }
    return true
  }

  CORE_ACTIONS.forwardFormAction = function (actionObject, pages, components, submitURL = false, currentPageComponents = null) {
    var targetPageId = actionObject.params[0].paramValue
    var resolvedParams
    var validationSuccess = true

    for (let index in actionObject.params) {
      if (actionObject.params[index].paramKey === 'page_id') {
        targetPageId = actionObject.params[index].paramValue
      }
    }

    var pageDataObject = HELPER_METHODS.getPageData(currentPageComponents)

    if (!pageDataObject) {
      return false
    }

    // update dataRecord with recordType, fields and sublist values
    if (pageDataObject.recordName) {
      PARENT_ELEMENT_COMPONENT.$store.commit('ADD_RECORD_TYPE', pageDataObject.recordName)
    }
    if (pageDataObject.standardFields) {
      PARENT_ELEMENT_COMPONENT.$store.commit('ADD_FIELDS_TO_RECORD', pageDataObject.standardFields)
    }
    if (pageDataObject.sublists) {
      for (var sublistName in pageDataObject.sublists) {
        PARENT_ELEMENT_COMPONENT.$store.commit('ADD_SUBLIST_TO_RECORD', {
          sublistName: sublistName,
          sublistObject: pageDataObject.sublists[sublistName]
        })
      }
    }

    if (pageDataObject.auxFields) {
      PARENT_ELEMENT_COMPONENT.$store.commit('ADD_AUX_PARAMS_TO_RECORD', pageDataObject.auxFields)
    }

    resolvedParams = HELPER_METHODS.resolveParams(actionObject.params)

    PARENT_ELEMENT_COMPONENT.$store.commit('RESET_CURRENT_PAGE_ERROR_MESSAGE')

    axios.all([serverSideValidation(), clientSideValidation()])
      .then(axios.spread(function (acct, perms) {
        // Both requests are now complete
        if (validationSuccess) {
          validationSuccessAction()
        }
      }));

    function serverSideValidation() {
      if (actionObject.url) {
        return axios.get('https://system.netsuite.com' + actionObject.url, {
          params: {'dataRecord': PARENT_ELEMENT_COMPONENT.$store.state.dataRecord}
        })
          .then(response => {
            console.log(response.data)
            if (!response.data.isValid) {
              // validation failure
              validationSuccess = false
              PARENT_ELEMENT_COMPONENT.$store.commit('SET_CURRENT_PAGE_ERROR_MESSAGE', response.data.errorMessage)  
            }

          })
      }
    }

    function clientSideValidation() {
      if (actionObject.clientFilePath && actionObject.clientFunctionName) {
        var filePath = actionObject.clientFilePath
        return axios.get(filePath)
          .then(response => {
            /* eslint-disable no-eval */
            USER_SCRIPT = eval(response.data)
            var functionName = actionObject.clientFunctionName
            var paramsObject = HELPER_METHODS.resolveParams(actionObject.params)
            var executionResponse = HELPER_METHODS.executeFunctionByName(functionName, USER_SCRIPT, paramsObject)
            console.log(executionResponse)
            if (!executionResponse.isValid) {
              validationSuccess = false
              // validation failure
              PARENT_ELEMENT_COMPONENT.$store.commit('SET_CURRENT_PAGE_ERROR_MESSAGE', executionResponse.errorMessage)
            }
          })
      }
    }

    function submitAction() {
      if (submitURL) {
        if (submitURL) {
          submitURL = 'https://system.netsuite.com' + actionObject.url
        }
        // Dispatch save record action and pass mutation id
        PARENT_ELEMENT_COMPONENT.$store.dispatch({
          type: 'SAVE_RECORD',
          actionUrl: submitURL,
          params: {'dataRecord': PARENT_ELEMENT_COMPONENT.$store.state.dataRecord},
          mutationId: 'UPDATE_RECORD_LINK'
        })
      }
    }

    function conditionBasedPageId() {
      var conditionObject
      if (actionObject.conditions && actionObject.conditions.length > 0) {
        for (let index in actionObject.conditions) {
          conditionObject = actionObject.conditions[index]
          console.log(conditionObject.conditionExpression)
          var resolvedConditionExpression = HELPER_METHODS.resolveConditionExpression(conditionObject.conditionExpression)
          console.log(resolvedConditionExpression)
          if (eval(resolvedConditionExpression)) {
            targetPageId = conditionObject.conditionValue
          }
        }
      }
    }

    function validationSuccessAction() {
      submitAction()
      conditionBasedPageId()
      PARENT_ELEMENT_COMPONENT.$store.commit('SET_CURRENT_PAGE', targetPageId)
    }

  }

  CORE_ACTIONS.backwardFormAction = function (actionObject, pages, components, currentPageComponents = null) {
    var targetPageId = actionObject.params[0].paramValue
    var pageDataObject = HELPER_METHODS.getPageData(currentPageComponents)

    if (!pageDataObject) {
      return false
    }

    // update dataRecord with recordType, fields and sublist values
    if (pageDataObject.recordName) {
      PARENT_ELEMENT_COMPONENT.$store.commit('RESET_RECORD_TYPE')
    }
    if (pageDataObject.standardFields) {
      PARENT_ELEMENT_COMPONENT.$store.commit('REMOVE_FIELDS_FROM_RECORD', pageDataObject.standardFields)
    }
    if (pageDataObject.sublists) {
      for (var sublistName in pageDataObject.sublists) {
        PARENT_ELEMENT_COMPONENT.$store.commit('REMOVE_SUBLIST_FROM_RECORD', {
          sublistName: sublistName,
          sublistObject: pageDataObject.sublists[sublistName]
        })
      }
    }

    if (pageDataObject.auxFields) {
      PARENT_ELEMENT_COMPONENT.$store.commit('REMOVE_AUX_PARAMS_FROM_RECORD', pageDataObject.auxFields)
    }

    PARENT_ELEMENT_COMPONENT.$store.commit('SET_CURRENT_PAGE', targetPageId)
    return true
  }

  CORE_ACTIONS.getOnLoadDataAction = function (actionObject, actionType, actionParentComponent) {
    var url = actionObject.url
    var paramObject = actionObject.params
    var params
    if (paramObject) {
      params = HELPER_METHODS.resolveParams(paramObject)
    } else {
      params = {}
    }
    if (actionType === 'restlet') {
      axios.get('https://system.netsuite.com' + url, {
        params: params
      })
        .then(response => {
          if (actionParentComponent.componentType === 'DropDown' || actionParentComponent.componentType === 'UOM' || actionParentComponent.componentType === 'Checkbox') {
            actionParentComponent.componentData.push(...response.data)
          } else if (actionParentComponent.componentType === 'DataTable') {
            for (var key in response.data) {
              response.data[key].clicked = false
            }
            actionParentComponent.componentData.push(...response.data)
            return true
          } else if (actionParentComponent.componentType === 'NumericStepper') {
            actionParentComponent.componentValue = response.data
          } else {
            actionParentComponent.setComponentData(response.data)
          }
      })
    }
  }

  CORE_ACTIONS.executeClientAction = function (actionObject) {
    var filePath = actionObject.clientFilePath
    axios.get(filePath)
      .then(response => {
      /* eslint-disable no-eval */
      USER_SCRIPT = eval(response.data)
      var functionName = actionObject.clientFunctionName
      var paramsObject = HELPER_METHODS.resolveParams(actionObject.params)
      var executionResponse = HELPER_METHODS.executeFunctionByName(functionName, USER_SCRIPT, paramsObject)
      console.log(executionResponse)
      return executionResponse
    })
  }

  HELPER_METHODS.executeFunctionByName = function (functionName, context, args) {
    console.log(functionName)
    args = Array.prototype.slice.call(arguments, 2)
    var namespaces = functionName.split('.')
    var func = namespaces.pop()
    for (var i = 0; i < namespaces.length; i++) {
      context = context[namespaces[i]]
    }
    return context[func].apply(context, args)
  }

  HELPER_METHODS.getPageData = function (currentPageComponents) {
    var recordName = ''
    var standardFieldsObject = {}
    var sublistsObject = {}
    var auxFields = {}
    var component
    var dataValid = true

    for (var index in currentPageComponents) {
      component = currentPageComponents[index]

      if (['TextBox'].includes(component.componentType) && component.propsObject.isMandatory && !component.componentValue) {
        component.mandatoryFieldError = true
        dataValid = false
        continue
      }

      var fieldDetails = component.propsObject

      if (fieldDetails.recordName === 'aux') {
        auxFields[fieldDetails.elementName] = component.componentValue
      } else if (fieldDetails.recordName && fieldDetails.fieldName) {
        // update data record name
        if (fieldDetails.recordName) {
          if (!recordName) {
            recordName = fieldDetails.recordName
          }
        }

        // update sublist name and initialize fields and sublist objects
        if (fieldDetails.sublistName) {
          if (!(fieldDetails.sublistName in sublistsObject)) {
            sublistsObject[fieldDetails.sublistName] = {}
          }

          if (fieldDetails.elementType === 'HiddenValuesSet') {
            for (let ind in fieldDetails.hiddenFieldsArray) {
              sublistsObject[fieldDetails.sublistName][fieldDetails.hiddenFieldsArray[ind]] = document.getElementById(fieldDetails.hiddenFieldsArray[ind]).value
            }
          } else {
            sublistsObject[fieldDetails.sublistName][fieldDetails.fieldName] = component.componentValue
          }
        } else {
          if (fieldDetails.elementType === 'HiddenValuesSet') {
            for (let ind in fieldDetails.hiddenFieldsArray) {
              standardFieldsObject[fieldDetails.hiddenFieldsArray[ind]] = document.getElementById(fieldDetails.hiddenFieldsArray[ind]).value
            }
          } else {
            standardFieldsObject[fieldDetails.fieldName] = component.componentValue
          }
        }
      }
    }

    if (!dataValid) {
      return false
    }

    var pageDataObject = {
      recordName: recordName,
      standardFields: standardFieldsObject,
      sublists: sublistsObject,
      auxFields: auxFields
    }
    return pageDataObject
  }

  HELPER_METHODS.resolveParams = function (paramsArray) {
    var paramsObject = {}
    paramsArray = HELPER_METHODS.sortByKey(paramsArray, 'paramName')

    for (var ind in paramsArray) {
      var paramKey = paramsArray[ind].paramKey
      var paramVal = null
      if (paramsArray[ind].paramSource === 'State') {
        paramVal = PARENT_ELEMENT_COMPONENT.$store.getters.getParamsFromState(paramsArray[ind].paramValue)
      } else if (paramsArray[ind].paramSource === 'Current Page') {
        paramVal = MOBILE_API.mobileGetValueFromPage(paramsArray[ind].paramValue)
      } else if (paramsArray[ind].paramSource === 'Features') {
        paramVal = PARENT_ELEMENT_COMPONENT.$store.getters.getAppConfig.features[paramsArray[ind].paramValue]
      } else if (paramsArray[ind].paramSource === '') {
        paramVal = paramsArray[ind].paramValue
      }
      paramsObject[paramKey] = paramVal
    }
    return paramsObject
  }

  HELPER_METHODS.resolveConditionExpression = function (conditionExpression) {
    var paramKeys = []
    // regex to find keys between {{}}
    var rxp = /\{\{(.*?)\}\}/g
    var matchedKey = rxp.exec(conditionExpression)

    while (matchedKey) {
      paramKeys.push(matchedKey[1])
      matchedKey = rxp.exec(conditionExpression)
    }

    for (let key in paramKeys) {
      conditionExpression = conditionExpression.replace('{{' + paramKeys[key] + '}}', 'resolvedParams.' + paramKeys[key])
    }
    return conditionExpression
  }

  HELPER_METHODS.sortByKey = function (array, key) {
    return array.sort(function (a, b) {
      var x = a[key]; var y = b[key]
      return ((x < y) ? -1 : ((x > y) ? 1 : 0))
    })
  }

  MOBILE_API.mobileGetValueFromPage = function (elementName) {
    for (var index in CURRENT_PAGE_COMPONENT.$children) {
      var compRef = CURRENT_PAGE_COMPONENT.$children[index]
      if (compRef.propsObject.elementName === elementName) {
        return compRef.componentValue
      }
    }
  }

  MOBILE_API.mobileSetValueInPage = function (elementName, value) {
    for (var index in CURRENT_PAGE_COMPONENT.$children) {
      var compRef = CURRENT_PAGE_COMPONENT.$children[index]
      if (compRef.propsObject.elementName === elementName) {
        compRef.componentValue = value
      }
    }
  }

  MOBILE_API.mobileEnableField = function (elementName) {
    for (var index in CURRENT_PAGE_COMPONENT.$children) {
      var compRef = CURRENT_PAGE_COMPONENT.$children[index]
      if (compRef.propsObject.elementName === elementName) {
        compRef.propsObject.isDisabled = false
      }
    }
  }

  MOBILE_API.mobileDisableField = function (elementName) {
    for (var index in CURRENT_PAGE_COMPONENT.$children) {
      var compRef = CURRENT_PAGE_COMPONENT.$children[index]
      if (compRef.propsObject.elementName === elementName) {
        compRef.propsObject.isDisabled = true
      }
    }
  }

  MOBILE_API.mobileShowField = function (elementName) {
    for (var index in CURRENT_PAGE_COMPONENT.$children) {
      var compRef = CURRENT_PAGE_COMPONENT.$children[index]
      if (compRef.propsObject.elementName === elementName) {
        compRef.isVisible = true
      }
    }
  }

  MOBILE_API.mobileHideField = function (elementName) {
    for (var index in CURRENT_PAGE_COMPONENT.$children) {
      var compRef = CURRENT_PAGE_COMPONENT.$children[index]
      if (compRef.propsObject.elementName === elementName) {
        compRef.isVisible = false
      }
    }
  }

  MOBILE_API.SUM = function (sublistLocation, fieldName) {
    debugger
    var sum = 0
    var sublistArray = PARENT_ELEMENT_COMPONENT.$store.getters.getParamsFromState(sublistLocation)
    var row
    for (let index in sublistArray) {
      row = sublistArray[index]
      // to-do: remove the parseInt as it will not be required after data type handling inside component
      sum += parseInt(row[fieldName])
    }
    return sum
  }

  MOBILE_API.COUNT = function (sublistLocation) {
    var sublistArray = PARENT_ELEMENT_COMPONENT.$store.getters.getParamsFromState(sublistLocation)
    return sublistArray.length
  }

  return {
    resolveAction: resolveAction
  }
}())

export default actionAPI
