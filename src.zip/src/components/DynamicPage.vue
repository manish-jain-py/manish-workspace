<template>

  <div class="content">

    <div class="debuggingText">{{ dataRecord }}</div>
    <div>
      <div v-for="component in pageComponents" v-if="components[component].elementType !== 'ActionButton'" :key="components[component].elementName">
        <component v-bind:is="components[component].elementType"
                  v-bind:propsObject="components[component]" @sendAction="sendAction"></component>
      </div>
    </div>
    <div v-if="errorMessageDisplay" class="my-notify-error">
      <div v-for="error in errorMessages">
        {{ error }}
      </div>
    </div>
    <div class="button-container">
      <div class="button-row" v-for="component in pageComponents" v-if="components[component].elementType === 'ActionButton'" :key="components[component].elementName">
        <component v-bind:is="components[component].elementType"
                  v-bind:propsObject="components[component]" @sendAction="sendAction"></component>
      </div>
    </div>

  </div>

</template>

<script>

  import store from '../components/store'
  import actionAPI from './common/MobileAction.js'
  import * as mutationTypes from '../components/store/mutation-types.js'

  // import all base components
  import TextBox from '../components/base_components/TextBox.vue'
  import ActionButton from './base_components/ActionButton.vue'
  import DropDown from './base_components/DropDown.vue'
  import DataTable from '../components/base_components/DataTable.vue'
  import HiddenValuesSet from '../components/base_components/HiddenValuesSet.vue'
  import HiddenObject from '../components/base_components/HiddenObject.vue'
  import Anchor from '../components/base_components/Anchor.vue'
  import MenuIcon from '../components/base_components/MenuIcon.vue'
  import Date from '../components/base_components/Date.vue'
  import NumericStepper from '../components/base_components/NumericStepper.vue'
  import Checkbox from '../components/base_components/Checkbox.vue'
  import DynamicText from '../components/base_components/DynamicText.vue'
  import UOM from '../components/base_components/UOM.vue'

  export default {

    name: store.state.currentPage,

    props: ['currentPage'],

    computed: {
      appConfig: function () {
        return this.$parent.appConfig
      },
      components: function () {
        return this.appConfig.components
      },
      pageComponents: function () {
        if (this.currentPage) {
          return this.$parent.pages[store.state.currentPage].components
        }
      },
      errorMessages: function () {
        return store.state.currentPageErrorMessage
      },
      errorMessageDisplay: function () {
        if (this.errorMessages.length !== 0) {
          return true
        } else {
          return false
        }
      },
      dataRecord: {
        cache: false,
        get: function () {
          return store.state.dataRecord
        }
      }
    },

    components: {
      TextBox,
      ActionButton,
      DropDown,
      DataTable,
      HiddenValuesSet,
      HiddenObject,
      Anchor,
      MenuIcon,
      Date,
      NumericStepper,
      Checkbox,
      DynamicText,
      UOM
    },

    methods: {
      sendAction: function (actionObject, parentComponent) {
        actionAPI.resolveAction(actionObject, parentComponent, this.pages, this.components, null, this.$children)
      }
    },

    created: function () {
      this.$store.commit(mutationTypes.RESET_CURRENT_PAGE_ERROR_MESSAGE)
    }

  }

</script>

<style>
  .my-notify-error {
    padding:10px;
    margin:10px 0;

  }

  .my-notify-error:before {
    font-family:FontAwesome;
    font-style:normal;
    font-weight:400;
    speak:none;
    display:inline-block;
    text-decoration:inherit;
    width:1em;
    margin-right:.2em;
    text-align:center;
    font-variant:normal;
    text-transform:none;
    line-height:1em;
    margin-left:.2em;
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale
  }

  .my-notify-error {
    color: #D8000C;
    background-color: #FFD2D2;
  }
</style>
