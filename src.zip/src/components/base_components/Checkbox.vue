<template>
  <div class="checkbox-container">
    <label :for="propsObject.elementName">{{propsObject.label}}</label><label v-if="propsObject.isMandatory" class="mandatory-red">*</label>
    <div class="checkbox" v-for="item in componentData" :key="item.id">
      <input type="checkbox" :name="propsObject.elementName" v-model="item.isChecked" :disabled="propsObject.isDisabled" :value="item.id" :id="item.id" @change="onCheck" />
      <label :for="item.id">{{item.label}}</label>
    </div>
    <small v-if="mandatoryFieldError" class="mandatory-red">
      This field is mandatory
    </small>
  </div>
</template>

<style scoped>
  .mandatory-red{
    color: #c77f02
  }
  .checkbox-container{
    font-size: 36px;
  }
  input[type=checkbox]{
    height: 36px;
    margin-left: 0;
    position: inherit;
    width: 36px;
  }
</style>

<script>
  import actionAPI from '../common/MobileAction.js'
  export default {
    name: 'Checkbox',
    data () {
      return {
        componentType: 'Checkbox',
        componentData: [],
        mandatoryFieldError: false
      }
    },
    props: ['propsObject'],
    computed: {
      componentValue () {
        let array = []
        for (let key in this.componentData) {
          if (this.componentData[key].isChecked) {
            array.push(this.componentData[key])
          }
        }
        return array
      }
    },
    created () {
      if (this.propsObject.onLoadEvent) {
        actionAPI.resolveAction(this.propsObject.onLoadEvent, this)
      } else if (this.propsObject.inputId && this.propsObject.inputValue) {
        let ids = this.propsObject.inputId
        let values = this.propsObject.inputValue
        let isCheckeds = this.propsObject.isChecked
        let arrIds = ids.split(',')
        let arrValues = values.split(',')
        let arrIsCheckeds = isCheckeds.split(',')
        let data = []
        for (let i = 0; i < arrIds.length && i < arrValues.length; i++) {
          let obj = {}
          obj.id = arrIds[i]
          obj.label = arrValues[i]
          if (arrIsCheckeds.length > i) {
            if (arrIsCheckeds[i] === 'true') {
              obj.isChecked = true
            } else {
              obj.isChecked = false
            }
          } else {
            obj.isChecked = false
          }
          data.push(obj)
        }
        this.componentData = data
      }
      return this.propsObject.items
    },
    watch: {
      componentValue () {
        if (this.propsObject.isMandatory) {
          if (this.componentValue.length === 0) {
            this.mandatoryFieldError = true
          } else {
            this.mandatoryFieldError = false
          }
        }
      }
    },
    methods: {
      onCheck () {
        if (this.propsObject.onCheck) {
          actionAPI.resolveAction(this.propsObject.onCheck, this)
        }
      }
    }
  }
</script>
