<template>

  <div class="dropdown">
    <v-select v-model="componentValue" :options="componentData"></v-select>
  </div>

</template>

<script>

  import vSelect from 'vue-select'
  import actionAPI from '../common/MobileAction.js'

  export default {

    name: 'DropDown',

    data: function () {
      return {
        componentType: 'DropDown',
        componentValue: {'label': this.propsObject.label, 'value': -1},
        componentData: [],
        extraParamObject: {}
      }
    },

    props: ['propsObject'],

    components: {
      vSelect
    },

    methods: {
      setDefaultValue () {
        this.componentData = [{'label': this.propsObject.label, 'value': -1}]        
        if (this.propsObject.onLoadEvent) {
          actionAPI.resolveAction(this.propsObject.onLoadEvent, this)
        }

        if (this.$store.state.dataRecord['auxParams']['warehouse']) {
          this.componentValue = this.$store.state.dataRecord['auxParams']['warehouse']
        }
      },
      
      setComponentValue () {       
      }
    },

    created: function () {
      this.setDefaultValue()
    },

    mounted: function () {
      this.setComponentValue()
    }

  }

</script>

<style>
  /*@import './styles/DropDown.scss';*/
</style>
