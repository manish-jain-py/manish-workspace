<template>
  <div class="actionButton">
    <button id="propsObject.name" class="button" @click="sendAction">{{ propsObject.label }}</button>
  </div>

</template>

<script>

  export default {

    name: 'ActionButton',

    data: function () {
      return {
        componentType: 'ActionButton'
      }
    },

    props: ['propsObject'],

    methods: {

      sendAction: function () {
        var actionObject = this.propsObject.onClickEvent
        this.$emit('sendAction', actionObject, this)
      }

    }

  }

</script>

<style lang="scss">

  @import './styles/ActionButton.scss';

</style>
