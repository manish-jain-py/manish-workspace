<template>
  <div>
    <span :id="propsObject.elementName" v-html="componentValue"></span>
  </div>
</template>

<style>

</style>

<script>
  // import * as getters from '../store/getters.js'
  export default {
    name: 'DynamicText',
    data () {
      return {
        componentType: 'DynamicText',
        componentValue: ''
      }
    },
    props: ['propsObject'],
    created () {
      let regex = /{{(.*?)}}/g
      let store = this.$store
      this.componentValue = this.propsObject.inputValue.replace(regex, function (exp) {
        let pathArr = exp.substring(2, exp.length - 2)
        let value = store.getters.getParamsFromState(pathArr)
        return value
      })
    }
  }
</script>
