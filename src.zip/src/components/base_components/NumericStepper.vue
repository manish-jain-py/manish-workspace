<template>
  <div class="numeric-stepper-container">
    <div v-if="showLabel">
      <label>{{propsObject.label}}</label>
      <label v-if="propsObject.isMandatory" class="mandatory-red">*</label>
    </div>
    <button v-if="showButton" :disabled="isNegButtonDisabled" @click="onDecrement">-</button>
    <input type="number"
           :min="minComponentValue"
           :max="maxComponentValue"
           :value="componentValue"
           @change="updateValue($event.target.value)"
           :disabled="isInputDisabled"/>
    <button v-if="showButton" :disabled="isPosButtonDisabled" @click="onIncrement">+</button>
    <small v-if="!regexMatch">
      Incorrect format
    </small>
    <small v-if="mandatoryFieldError">
      This field is mandatory
    </small>
  </div>
</template>

<style scoped>
  button{
    width: 65px;
    height: 65px;
    font-size: 36px;
    cursor: pointer;
    border: 0;
    border-radius: 3px;
  }

  input{
    border: 0;
    border-radius: 3px;
    height: 63px;
    width: 100px;
    font-size: 36px;
    text-align: center;
  }

  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }

  button:disabled{
    cursor: default;
    background-color: #444;
  }

  .mandatory-red{
    color: #c77f02
  }

  .numeric-stepper-container{
    font-size: 36px;
  }
</style>

<script>
  import actionAPI from '../common/MobileAction.js'
  export default {
    name: 'NumericStepper',
    data () {
      return {
        componentType: 'NumericStepper',
        mandatoryFieldError: false,
        regexMatch: true,
        isNegButtonDisabled: true,
        isPosButtonDisabled: false,
        isInputDisabled: false,
        minComponentValue: 0,
        maxComponentValue: Infinity,
        showLabel: true,
        showButton: false
      }
    },
    props: {
      propsObject: {
        type: Object,
        required: true
      },
      subComponent: {
        type: Boolean,
        default: false
      },
      value: {
        type: [Number, String],
        default: 0
      }
    },
    computed: {
      componentValue () {
        return this.value
      }
    },
    created () {
      this.showLabel = !this.subComponent
      this.minComponentValue = this.propsObject.minValue ? this.propsObject.minValue : 0
      this.maxComponentValue = this.propsObject.maxValue ? this.propsObject.maxValue : Infinity
      if (this.propsObject.onLoadEvent) {
        actionAPI.resolveAction(this.propsObject.onLoadEvent, this)
      }
      if (this.propsObject.isDisabled) {
        this.isNegButtonDisabled = true
        this.isPosButtonDisabled = true
        this.isInputDisabled = true
      }
    },
    methods: {
      onDecrement () {
        this.value--
        if (this.value === 0) {
          this.isNegButtonDisabled = true
        }
        this.isPosButtonDisabled = false
      },
      onIncrement () {
        this.value++
        if (this.value === this.maxComponentValue) {
          this.isPosButtonDisabled = true
        }
        this.isNegButtonDisabled = false
      },
      isValidPositiveNumber (number) {
        let regex = /^\d*\.{0,1}\d*$/
        return regex.test(number)
      },
      isValidCustomRegex (pattern, string) {
        if (pattern) {
          let custRegex = new RegExp(pattern)
          if (custRegex.test(string)) {
            return false
          }
        }
        return true
      },
      updateValue (value) {
        let integer = value
        if (this.isValidPositiveNumber(integer)) {
          integer = parseFloat(integer)
          integer = isNaN(integer) ? 0 : integer
          if (integer > this.maxComponentValue) {
            integer = this.maxComponentValue
          }
        } else {
          integer = 0
        }
        if (!this.isValidCustomRegex(this.propsObject.regex, integer)) {
          integer = 0
        }
        if (integer === 0) {
          this.isNegButtonDisabled = true
          this.isPosButtonDisabled = false
        } else if (integer === this.maxComponentValue) {
          this.isNegButtonDisabled = false
          this.isPosButtonDisabled = true
        } else {
          this.isNegButtonDisabled = false
          this.isPosButtonDisabled = false
        }
        if (this.subComponent) {
          this.$emit('input', integer)
        } else {
          this.componentValue = integer
        }
      }
    }
  }
</script>
