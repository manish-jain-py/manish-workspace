<template>
    <div>
      <numeric-stepper
        :propsObject="propsObject"
        v-model="componentValue.quantity"
        :subComponent=true
        class="numeric-stepper"/>
      <select v-if="Object.keys(unitsList).length > 1" v-model="componentValue.unit">
        <option v-for="element in unitsList" :key="element.internalid" :value="element.internalid">{{element.pluralname}}</option>
      </select>
      <label v-else>{{unitsList[componentValue.unit] === undefined ? '' : unitsList[componentValue.unit].pluralname}}</label>
      <button v-if="componentValue.showRemove" @click="removeComponent(index)">-</button>
    </div>
</template>

<style scoped>
  button{
    width: 60px;
    height: 60px;
    font-size: 24px;
    cursor: pointer;
    border: 0;
    border-radius: 3px;
    font-weight: 400;
  }

  .numeric-stepper{
    display: inline;
  }

  select{
    border-radius: 3px;
    height: 63px;
    font-size: 24px;
    text-align: center;
  }

  input{
    border-radius: 3px;
    height: 63px;
    width: 100px;
    font-size: 24px;
    text-align: center;
  }

  label{
    height: 65px;
    font-size: 24px;
    font-weight: 400;
  }
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }

</style>

<script>
  import NumericStepper from './NumericStepper.vue'
  export default {
    name: 'InlineUOM',
    data () {
      return {
        componentType: 'InlineUOM'
      }
    },
    props: {
      componentValue: {
        type: Object,
        required: true
      },
      componentData: {
        type: Object,
        required: true
      },
      index: {
        type: Number,
        required: true
      },
      unUsedUnitsList: Array,
      propsObject: Object
    },
    components: {
      NumericStepper
    },
    created () {
    },
    computed: {
      unitsList () {
        let obj = {}
        let unit = this.componentValue.unit
        obj[unit] = this.componentData[unit]
        for (let index in this.unUsedUnitsList) {
          unit = this.unUsedUnitsList[index]
          obj[unit] = this.componentData[unit]
        }
        return obj
      }
    },
    methods: {
      removeComponent (index) {
        this.$emit('removeEntry', index)
      }
    }
  }
</script>
