<template>

  <div>
    <div class="alert alert-warning">
      <strong>Warning!</strong> We noticed that you were in the middle of a session.
    </div>
    <div class="button-container">
      <div class="button-row">
        <div class="actionButton">
          <button class="button" @click="setRestoreState(true)">Restore Last Session</button>
        </div>
      </div>

      <div class="button-row">
        <div class="actionButton">
          <button class="button" @click="setRestoreState(false)">Start Fresh</button>
        </div>
      </div>
    </div>
  </div>

</template>

<script>

  import state from '../store/state.js'

  export default {

    name: 'ReloadModal',

    data: function () {
      return {
        componentType: 'ReloadModal'
      }
    },

    methods: {
      setRestoreState: function (usePrevState) {
        if (!usePrevState) {
          localStorage.removeItem(state.storageName)
          this.$store.commit('RESET_STATE')
          this.$store.commit('SET_CURRENT_PAGE', this.$parent.appConfig.defaults.landingPage)
        }
        this.$parent.reloadFlag = false
      }
    }

  }
</script>

<style lang="scss">

  @import './styles/ActionButton.scss';

</style>