<template>
  <div>
    <div v-if="showLabel">
      <label :for="propsObject.elementName" class="title">{{propsObject.label}}</label>
      <label v-if="propsObject.isMandatory" class="mandatory-red title">*</label>
    </div>
    <inline-u-o-m v-for="(value, index) in entries"
                  :componentValue="value"
                  :componentData="componentData"
                  :index="index"
                  :key="index"
                  :unUsedUnitsList="unUsedUnitsList"
                  :propsObject="propsObject"
                  @removeEntry="removeEntry"/>
    <div>
      <button v-if="unUsedUnitsList.length > 0" @click="onClick">Add UOM</button>
    </div>
    <small v-if="!regexMatch">
      Incorrect format
    </small>
    <small v-if="mandatoryFieldError">
      This field is mandatory
    </small>
  </div>
</template>

<style scoped>
  button{
    height: 65px;
    font-size: 24px;
    cursor: pointer;
    border: 0;
    border-radius: 3px;
    margin-top: 10px;
    margin-bottom: 10px;
  }

  input{
    border-radius: 3px;
    height: 63px;
    width: 100px;
    font-size: 24px;
    text-align: center;
  }
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }

  select{
    border-radius: 3px;
    height: 63px;
    font-size: 24px;
    text-align: center;
  }

  label{
    height: 65px;
    font-size: 24px;
    font-weight: 400;
  }

  .title{
    font-size: 30px;
    font-weight: 700;
  }

  .mandatory-red{
    color: #c77f02
  }
</style>

<script>
  import InlineUOM from './InlineUOM.vue'
  import axios from 'axios'
  // import actionAPI from '../common/MobileAction.js'
  export default {
    name: 'UOM',
    data () {
      return {
        componentType: 'UOM',
        componentData: {},
        mandatoryFieldError: false,
        regexMatch: true,
        entries: [],
        showLabel: true
      }
    },
    props: ['propsObject'],
    components: {
      InlineUOM
    },
    created () {
      let getParamsFromState = this.$store.getters.getParamsFromState
      let inputValue = this.propsObject.inputValue
      axios.get('https://system.netsuite.com/app/site/hosting/restlet.nl?script=145&deploy=1', {
        params: {custparam_item: getParamsFromState(inputValue).itemValue}
      }).then(response => {
        this.componentData = response.data
        this.addEntry(0, getParamsFromState(inputValue).units)
      })
    },
    computed: {
      unUsedUnitsList () {
        let arr = []
        for (let componentDataKey in this.componentData) {
          let isSelected = false
          for (let index in this.entries) {
            if (componentDataKey === this.entries[index].unit) {
              isSelected = true
              break
            }
          }
          if (!isSelected) {
            arr.push(componentDataKey)
          }
        }
        return arr
      },
      componentValue () {
        let totalValue = 0
        for (let index in this.entries) {
          if (this.unit === '') {
            totalValue += this.entries.quantity
          } else {
            let entry = this.entries[index]
            totalValue += (entry.quantity * this.componentData[entry.unit].conversionrate)
          }
        }
        return totalValue
      }
    },
    watch: {
    },
    methods: {
      onClick () {
        let length = this.entries.length
        this.entries[length - 1].showRemove = true
        this.addEntry(0, this.unUsedUnitsList[0])
      },
      removeEntry (index) {
        this.entries.splice(index, 1)
      },
      addEntry (quantity, unit, showRemove = false) {
        let obj = {}
        obj.quantity = quantity
        obj.unit = unit
        obj.showRemove = showRemove
        this.entries.push(obj)
      }
    }
  }
</script>
