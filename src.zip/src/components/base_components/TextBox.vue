<template>

  <div class="" v-show="isVisible">

    <div class="psg-label" v-bind:for="propsObject.elementName">{{ propsObject.label }}</div>
    <label class="starlabel" v-if="propsObject.isMandatory">*</label>
    <input  class="psg-textbox" v-model="componentValue" type="text" v-bind:id="propsObject.elementName"
           v-bind:placeholder="propsObject.placeholder" :disabled="propsObject.isDisabled">

    <small v-if="!regexMatch" class="text-danger">
      Incorrect format
    </small>

    <small v-if="mandatoryFieldError" class="text-danger">
      This field is mandatory
    </small>

  </div>

</template>

<script>

  export default {

    name: 'TextBox',

    data: function () {
      return {
        componentType: 'TextBox',
        componentValue: null,
        regexMatch: true,
        mandatoryFieldError: false,
        isVisible: true
      }
    },

    watch: {
      componentValue: function (newValue) {
        if (this.propsObject.regex) {
          var pattern = new RegExp(this.propsObject.regex)
          this.regexMatch = pattern.test(newValue)
        }
        if (newValue) {
          this.mandatoryFieldError = false
        } else {
          this.mandatoryFieldError = true
        }
      }
    },

    props: ['propsObject']

  }

</script>

<style lang="scss" scoped>

  @import './styles/TextBox.scss';

</style>
