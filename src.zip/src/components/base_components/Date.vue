<template>

  <div class="form-group">

    <date-picker v-if="propsObject.isDateRange" :label="propsObject.label" :format="propsObject.format" v-model="componentValue"
                 :not-before="notBefore" :not-after="notAfter" lang="en"
                 confirm range></date-picker>

    <date-picker v-else :format="propsObject.format" :label="propsObject.label" :not-before="notBefore"
                 :not-after="notAfter" v-model="componentValue" :first-day-of-week="1"
                 lang="en"></date-picker>

  </div>

</template>

<script>

  import DatePicker from 'vue2-datepicker'

  export default {
    name: 'Date',

    data () {
      return {
        componentType: 'Date',
        componentValue: ''
      }
    },

    computed: {
      notBefore: function () {
        return new Date(this.propsObject.minDate)
      },
      notAfter: function () {
        return new Date(this.propsObject.maxDate)
      }
    },

    props: ['propsObject'],

    components: {
      DatePicker
    },

    created: function () {
      if (this.propsObject.isDateRange) {
        this.componentValue = []
      }
    }
  }

</script>
