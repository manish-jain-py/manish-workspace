<template>

  <div>
      <input type="hidden" :id="propsObject.elementName" :value="componentData.val">
  </div>

</template>

<script>

  import actionAPI from '../common/MobileAction.js'

  export default {

    name: 'HiddenObject',

    data: function () {
      return {
        componentData: {name: undefined, val: undefined}
      }
    },

    computed: {
      componentValue: function () {
        return this.componentData
      }
    },

    props: ['propsObject'],

    methods: {
      setComponentData: function (data) {
        this.componentData = data
      }
    },

    created: function () {
      if (this.propsObject.onLoadEvent) {
        actionAPI.resolveAction(this.propsObject.onLoadEvent, this)
      }
    }

  }

</script>
