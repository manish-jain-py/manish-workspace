<template>

  <div class="psg-table">

    <div>
      <form>
        <div class="psg-label">Search</div>
        <input class="psg-textbox" name="query" v-model="searchQuery">
      </form>
    </div>

    <vue-table
      :data="componentData"
      :columns="gridColumns"
      :filter-key="searchQuery"
      @onClickFunction="selectItem">
    </vue-table>

  </div>

</template>

<script>

  import VueTable from './VueTable.vue'
  import actionAPI from '../common/MobileAction.js'

  export default {

    data: function () {
      return {
        componentType: 'DataTable',
        searchQuery: '',
        componentData: [],
        componentValue: null
      }
    },

    computed: {
      gridColumns: function () {
        return JSON.parse(this.propsObject.columnKeys)
      }
    },

    components: {
      VueTable
    },

    props: ['propsObject'],

    methods: {

      selectItem (entry) {
        this.componentValue = entry
        this.searchQuery = entry.name || entry.item // todo - update to column name
      }

    },

    created: function () {
      if (this.propsObject.onLoadEvent) {
        actionAPI.resolveAction(this.propsObject.onLoadEvent, this)
      }
      
      if (this.$store.state.currentPage === 'pageId_5' && this.$store.state.dataRecord['auxParams']['poTable']) {
        this.searchQuery = this.$store.state.dataRecord['auxParams']['poTable']['name']
      }

      if (this.$store.state.currentPage === 'pageId_6' && this.$store.state.dataRecord['auxParams']['itemTable']) {
        this.searchQuery = this.$store.state.dataRecord['auxParams']['itemTable']['item']
      }      

    }

  }

</script>
