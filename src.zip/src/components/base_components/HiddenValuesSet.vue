<template>

  <div>
    <div v-for="(hiddenObj, index) in componentData" :key="index">
      <input type="hidden" :id="hiddenObj.name" :value="hiddenObj.val">
    </div>
  </div>

</template>

<script>

    import actionAPI from '../common/MobileAction.js'

    export default {

        name: 'HiddenValuesSet',

        data: function () {
            return {
                componentData: []
            }
        },

        computed: {
            componentValue: function () {
                return this.componentData
            }
        },

        props: ['propsObject'],

        methods: {
            setComponentData: function (value) {
                this.componentData = value
            }
        },

        created: function () {
            if (this.propsObject.onLoadEvent) {
                actionAPI.resolveAction(this.propsObject.onLoadEvent, this)
            }
        }

    }

</script>
