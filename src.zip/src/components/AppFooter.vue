<template>

  <div class="footer">
    {{footerText}}
  </div>

</template>

<script>
  export default {

    name: 'AppFooter',

    data: function () {
      return {
        componentType: 'AppFooter',
        footerText: ''
      }
    },

    props: ['propsObject']
  }

</script>

<style lang="scss" scoped>

  @import './base_components/styles/AppFooter.scss';

</style>
