const state = {
  appConfig: {},
  storageName: 'psg-mobile-state',
  currentPage: '',
  dataRecord: {
    'recordType': '',
    'standardFields': {},
    'sublistNames': [],
    'sublists': {},
    'auxParams': {'recordLink': ''}
  },
  auxParams: {},
  pageList: {},
  loadedClientScripts: [],
  currentPageErrorMessage: []
}

export default state
