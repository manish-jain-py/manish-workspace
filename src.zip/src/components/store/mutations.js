import Vue from 'vue'
import * as types from './mutation-types'

const mutations = {

  [types.INITIALIZE_STORE] (state) {
    var browserStorage = localStorage.getItem(state.storageName)
    if (browserStorage) {
      this.replaceState(
        Object.assign(state, JSON.parse(browserStorage))
      )
    }
  },

  [types.RESET_STATE] (state) {
    var freshState = {
      appConfig: {},
      storageName: 'psg-mobile-state',
      currentPage: '',
      dataRecord: {
        'recordType': '',
        'standardFields': {},
        'sublistNames': [],
        'sublists': {},
        'auxParams': {'recordLink': ''}
      },
      auxParams: {},
      pageList: {},
      loadedClientScripts: [],
      currentPageErrorMessage: []
    }
  },

  [types.UPDATE_APP_CONFIG] (state, appConfig) {
    state.appConfig = appConfig
  },

  [types.SET_CURRENT_PAGE] (state, pageId) {
    if (state.currentPage === pageId) {
      Vue.set(state, 'currentPage', '')
    }
    Vue.set(state, 'currentPage', pageId)
  },

  [types.UPDATE_PAGE_LIST] (state, pageId, pageObj) {
    state.pageList[pageId] = pageObj;
  },

  [types.ADD_RECORD_TYPE] (state, recordType) {
    state.dataRecord.recordType = recordType
  },

  [types.RESET_RECORD_TYPE] (state) {
    state.dataRecord.recordType = ''
  },

  [types.ADD_AUX_PARAMS_TO_RECORD] (state, paramsObject) {
    for (var key in paramsObject) {
      state.dataRecord.auxParams[key] = paramsObject[key]
    }
  },

  [types.REMOVE_AUX_PARAMS_FROM_RECORD] (state, paramsObject) {
    for (var key in paramsObject) {
      delete state.dataRecord.auxParams[key]
    }
  },

  [types.ADD_FIELDS_TO_RECORD] (state, fieldsObject) {
    for (var field in fieldsObject) {
      state.dataRecord.standardFields[field] = fieldsObject[field]
    }
  },

  [types.REMOVE_FIELDS_FROM_RECORD] (state, fieldsObject) {
    for (var field in fieldsObject) {
      delete state.dataRecord.standardFields[field]
    }
  },

  [types.ADD_SUBLIST_TO_RECORD] (state, sublistDetails) {
    var sublistName = sublistDetails.sublistName
    var sublistObject = sublistDetails.sublistObject

    // create a new sublist in case of first time addition
    if (state.dataRecord.sublistNames.indexOf(sublistName) === -1) {
      state.dataRecord.sublistNames.push(sublistName)
      state.dataRecord.sublists[sublistName] = []
    }
    state.dataRecord.sublists[sublistName].push(sublistObject)
  },

  [types.REMOVE_SUBLIST_FROM_RECORD] (state, sublistDetails) {
    var sublistName = sublistDetails.sublistName
    var index = state.dataRecord.sublistNames.indexOf(sublistName);

    if (index > -1) {
      state.dataRecord.sublists[sublistName].pop()
    }

    if (sublistName && state.dataRecord.sublists[sublistName] && state.dataRecord.sublists[sublistName].length === 0) {
      delete state.dataRecord.sublists[sublistName]
      state.dataRecord.sublistNames.splice(index, 1)
    }
  },

  [types.UPDATE_RECORD_LINK] (state, link) {
    state.dataRecord.auxParams.recordLink = link
  },

  [types.ADD_TO_CLIENT_SCRIPTS] (state, filePath) {
    state.loadedClientScripts.push(filePath)
  },

  [types.RESET_CLIENT_SCRIPTS] (state) {
    state.loadedClientScripts = []
  },

  [types.SET_CURRENT_PAGE_ERROR_MESSAGE] (state, errorMessage) {
    state.currentPageErrorMessage.push(errorMessage)
    Vue.set(state, 'currentPageErrorMessage', state.currentPageErrorMessage)
  },

  [types.RESET_CURRENT_PAGE_ERROR_MESSAGE] (state) {
    Vue.set(state, 'currentPageErrorMessage', [])
  }

}

export default mutations
