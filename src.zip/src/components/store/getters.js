export const getAppConfig = (state) => {
  return state.appConfig
}

export const getRecordLink = (state) => {
  return state.dataRecord.auxParams.recordLink
}

export const getCurrentPageErrorMessage = (state) => {
  return state.currentPageErrorMessage
}

export const getALLClientScripts = (state) => {
  return state.loadedClientScripts
}

export const getParamsFromState = (state) => (paramLocation) => {
  var paramLocationArray = paramLocation.split(':')
  var parent = state
  for (var index in paramLocationArray) {
    parent = parent[paramLocationArray[index]]
  }
  return parent
}
