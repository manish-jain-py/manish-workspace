import axios from 'axios'

export const SAVE_RECORD = (context, payload) => {
  axios.get(payload.actionUrl, {
    params: payload.params
  })
    .then(response => {
      context.commit(payload.mutationId, response.data)
    })
}
